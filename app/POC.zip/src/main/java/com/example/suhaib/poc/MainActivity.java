package com.example.suhaib.poc;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.barteksc.pdfviewer.PDFView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{

    private String URL = "https://pdfsabi.000webhostapp.com/";
    private static final int PICK_FILE_REQUEST = 1;
    private static final String TAG = MainActivity.class.getSimpleName();
    private String selectedFilePath;
    private String SERVER_URL = URL + "uploadtest.php";
    FloatingActionButton bUpload;
    ProgressDialog dialog;
    GridView gv;
    ArrayAdapter<String> adapter;
    ArrayAdapter<String> update;
    String fetch = URL + "fetch.php";
    InputStream is = null;
    String line = null;
    String result = null;
    String[] data;
    DownloadManager dm;
    JSONArray ja;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M ) {
            checkPermission();
        }
        else {
            mainView();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        deleteFiles();
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        //sets the select file to all types of files
        intent.setType("application/pdf");
        //allows to select data and return it
        intent.setAction(Intent.ACTION_GET_CONTENT);
        //starts new activity to select file and return data
        startActivityForResult(Intent.createChooser(intent,"Choose File to Upload.."),PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK){
            if(requestCode == PICK_FILE_REQUEST){
                if(data == null){
                    //no data present
                    return;
                }


                Uri selectedFileUri = data.getData();
                selectedFilePath = FilePath.getPath(this,selectedFileUri);
                Log.i(TAG,"Selected File Path:" + selectedFilePath);
            }
        }
        if(selectedFilePath != null){
            Log.i(TAG,"Selected File Path:" + selectedFilePath);
//            selectedFilePath = selectedFilePath.split(".")[0] + ".enc";
            dialog = ProgressDialog.show(MainActivity.this,"","Uploading File...",true);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    //creating new thread to handle Http Operations
                    uploadFile(selectedFilePath);

                }
            }).start();
            getData();
            gv.setAdapter(update);
            mainView();
        }else{
            Toast.makeText(MainActivity.this,"Please choose a File First",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        deleteFiles();
        mainView();
    }

    //android upload file to server
    public void uploadFile(final String selectedFilePath){

        int serverResponseCode;

        HttpURLConnection connection;
        DataOutputStream dataOutputStream;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";


        int bytesRead,bytesAvailable,bufferSize;
        byte[] buffer;
        int maxBufferSize = 1024 * 1024;
        File selectedFile = new File(selectedFilePath);

        if (!selectedFile.isFile()){
            dialog.dismiss();
        }else{
            try{
                FileInputStream fileInputStream = new FileInputStream(selectedFile);
                URL url = new URL(SERVER_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setDoInput(true);//Allow Inputs
                connection.setDoOutput(true);//Allow Outputs
                connection.setUseCaches(false);//Don't use a cached Copy
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Connection", "Keep-Alive");
                connection.setRequestProperty("ENCTYPE", "multipart/form-data");
                connection.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                connection.setRequestProperty("uploaded_file",selectedFilePath);

                //creating new dataoutputstream
                dataOutputStream = new DataOutputStream(connection.getOutputStream());

                //writing bytes to data outputstream
                dataOutputStream.writeBytes(twoHyphens + boundary + lineEnd);
                dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
                        + selectedFilePath + "\"" + lineEnd);

                dataOutputStream.writeBytes(lineEnd);

                //returns no. of bytes present in fileInputStream
                bytesAvailable = fileInputStream.available();
                //selecting the buffer size as minimum of available bytes or 1 MB
                bufferSize = Math.min(bytesAvailable,maxBufferSize);
                //setting the buffer as byte array of size of bufferSize
                buffer = new byte[bufferSize];

                //reads bytes from FileInputStream(from 0th index of buffer to buffersize)
                bytesRead = fileInputStream.read(buffer,0,bufferSize);

                //loop repeats till bytesRead = -1, i.e., no bytes are left to read
                while (bytesRead > 0){
                    //write the bytes read from inputstream
                    dataOutputStream.write(buffer,0,bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable,maxBufferSize);
                    bytesRead = fileInputStream.read(buffer,0,bufferSize);
                }

                dataOutputStream.writeBytes(lineEnd);
                dataOutputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                serverResponseCode = connection.getResponseCode();
                String serverResponseMessage = connection.getResponseMessage();

                Log.i(TAG, "Server Response is: " + serverResponseMessage + ": " + serverResponseCode);

                //response code of 200 indicates the server status OK
                if(serverResponseCode == 200){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
//                            tvFileName.setText("File Upload completed.\n\n You can see the uploaded file here: \n\n" + "http://coderefer.com/extras/uploads/"+ fileName);
                        }
                    });
                }

                //closing the input and output streams
                fileInputStream.close();
                dataOutputStream.flush();
                dataOutputStream.close();



            } catch (FileNotFoundException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,"File Not Found",Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (MalformedURLException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "URL error!", Toast.LENGTH_SHORT).show();

            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Cannot Read/Write File!", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        }
    }

    private void getData() {
        try {
            URL url = new URL(fetch);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            is = new BufferedInputStream(conn.getInputStream());
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();

            while ((line = br.readLine()) != null) {
                sb.append(line).append("\n");
            }

            is.close();
            result = sb.toString();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        try {
            ja = new JSONArray(result);
            JSONObject jo;

            data = new String[ja.length()];

            for (int i = 0; i < ja.length(); i++) {
                jo = ja.getJSONObject(i);
                data[i] = jo.getString("Name");
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void mainView() {
        setContentView(R.layout.activity_main);
        bUpload = findViewById(R.id.fab);
        bUpload.setOnClickListener(this);
        gv = findViewById(R.id.GridView);
        StrictMode.setThreadPolicy((new StrictMode.ThreadPolicy.Builder().permitNetwork().build()));
        getData();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                String fileUrl = null;
                try {
                    fileUrl = getFilesDir() + "/pdf/"+ ja.getJSONObject(position).getString("Name");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                final String file = android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + fileUrl;
//                        android.os.Environment.getExternalStorageDirectory().getPath() + fileUrl
                File f = new File(file + ".enc");
                if (!(f).exists()) {
                    try {
                        Toast.makeText(getApplicationContext(), ja.getJSONObject(position).getString("Name") + " is downloading ",
                                Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    File mydir = new File(getFilesDir(), "/pdf");
                    if (!mydir.exists()) {
                        mydir.mkdirs();
                    }
                    dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                    Uri uri = null;
                    try {
                        uri = Uri.parse("https://pdfsabi.000webhostapp.com/" + (ja.getJSONObject(position).getString("Name")) + ".pdf");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    DownloadManager.Request request = new DownloadManager.Request(uri);
                    try {
                        request.setDestinationInExternalPublicDir(getFilesDir() + "/pdf", ja.getJSONObject(position).getString("Name") + ".pdf");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    dm.enqueue(request);
                    BroadcastReceiver receiver = new BroadcastReceiver() {
                        @Override
                        public void onReceive(Context context, Intent intent) {
                            try {
                                encrypt(file);
                            } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
                                e.printStackTrace();
                            }
                            viewPDF(file);
                        }
                    };
                    registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
                }
                else {
                    viewPDF(file);
                }
                deleteFiles();
            }
        });
    }

    public void viewPDF(String file) {
        try {
            decrypt(file);
        } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
            e.printStackTrace();
        }
        File f = new File(file + ".pdf");
        PDFView pdfViewer;
        setContentView(R.layout.activity_pdf_view);
        pdfViewer=(PDFView) findViewById(R.id.pdfviewer);
        pdfViewer.fromFile(f).load();
    }

    static void encrypt(String file) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        File f = new File(file + ".pdf");
        FileInputStream fis = new FileInputStream(f);
        FileOutputStream fos = new FileOutputStream(file + ".enc");
        System.out.println(file);

        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");
        @SuppressLint("GetInstance") Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, sks);
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);

        int b;
        byte[] d = new byte[8];
        while((b = fis.read(d)) != -1) {
            cos.write(d, 0, b);
        }

        cos.flush();
        cos.close();
        fis.close();
        if ( file.indexOf(".pdf") != -1 ) {
            f.delete();
        }
    }

    static void decrypt(String file) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
        File f = new File(file + ".enc");
        FileInputStream fis = new FileInputStream(f);
        FileOutputStream fos = new FileOutputStream(file + ".pdf");

        SecretKeySpec sks = new SecretKeySpec("MyDifficultPassw".getBytes(), "AES");
        @SuppressLint("GetInstance") Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, sks);
        CipherInputStream cis = new CipherInputStream(fis, cipher);

        int b;
        byte[] d = new byte[8];
        while((b = cis.read(d)) != -1) {
            fos.write(d, 0, b);
        }

        fos.flush();
        fos.close();
        cis.close();
    }

    private void deleteFiles(){
        ArrayList<String> result = new ArrayList<String>(); //ArrayList cause you don't know how many files there is
        File folder = new File(android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + getFilesDir() + "/pdf/"); //This is just to cast to a File type since you pass it as a String

        File[] filesInFolder = folder.listFiles(); // This returns all the folders and files in your path
        for (File file : filesInFolder) { //For each of the entries do:
            if (file.isFile()) {
                if(file.getName().contains(".pdf")){
                    file.delete();
                }
            }
        }
    }

    public void checkPermission()
    {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    123);
        }
        else {
            mainView();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            mainView();
        }
    }
}
